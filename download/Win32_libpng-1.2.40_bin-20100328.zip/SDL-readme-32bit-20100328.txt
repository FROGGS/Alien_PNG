This pack was build by KMX:
---------------------------
- build date: 19/03/2010
- compiled using gcc 4.4.3 toolchain provided by mingw-w64.sf.net project
- build scripts: http://svn.ali.as/cpan/users/kmx/strawberry_packs_devel/

Versions of SDL related libraries:
----------------------------------
SDL-1.2.14
SDL_gfx-2.0.20
SDL_ttf-2.0.9
SDL_image-1.2.10 - jpeg-7, libpng-1.2.40, tiff-3.9.1)
SDL_mixer-1.2.11 - flac-1.2.1, libmikmod-3.2.2, libsmpeg-SVN20090831,
                   libogg-1.1.4, libvorbis-1.2.3
SDL_sound-1.0.3  - flac-1.2.1, libmikmod-3.2.2, libsmpeg-SVN20090831
                   libogg-1.1.4, libvorbis-1.2.3, speex-1.2rc1,
                   libmodplug-0.8.7, timidity, mpglib
SDL_net-1.2.7
SDL_rtf-0.1.0
SDL_svg-1.2.0
SDL_Pango-0.1.2  - pango-1.26.2
SDL_vnc-1.0.0
libsmpeg-SVN20090831

All packs:
----------
zlib-1.2.3
libiconv-1.13.1
freeglut-2.6.0
expat-2.0.1
libxml2-2.7.3
jpeg-7
libpng-1.2.40
tiff-3.9.1
freetype-2.3.11
fontconfig-2.7.3
libogg-1.1.4
libvorbis-1.2.3
speex-1.2rc1
libmodplug-0.8.7
flac-1.2.1
libmikmod-3.2.2
SDL-1.2.14
SDL_image-1.2.10
SDL_net-1.2.7
SDL_gfx-2.0.20
SDL_ttf-2.0.9
libsmpeg-SVN20090831
SDL_mixer-1.2.11
SDL_rtf-0.1.0
SDL_svg-1.2.0	
SDL_sound-1.0.3
SDL_vnc-1.0.0
gettext-0.17
glib-2.23.1
pixman-0.17.4
cairo-1.8.8
pango-1.26.2
SDL_Pango-0.1.2
